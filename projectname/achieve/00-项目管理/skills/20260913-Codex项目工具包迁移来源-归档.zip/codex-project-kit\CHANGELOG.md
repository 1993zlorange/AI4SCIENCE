# 变更记录

## 2026-09-11

- 参照 `shiji-kb-main` 的 Butler、daily、msg、W0-W6 和多实例规则，补充通用的原子任务、队列/锁、并发、批处理幂等、来源追溯、质量评估、日志补记和 Skill 生命周期要求；删除 Wiki 页面、史料、地图和引文等业务规则。
- 从 `shiji-kb-main` 迁移通用方法与治理文档，保留来源副本供审阅。
- 新增 Codex 版 `project-governance`、`quality-gate`、`reflection-loop`、`transfer-pilot`、`skill-authoring`。
- 将 35 个对应源文件按 `00-META-*`、`SKILL_10*` 和 `claude-skill-spec.md` 原名重命名，并同步实施方案中的路径引用。
- 未迁移源项目专用 `.claude` 操作技能、数据、Wiki、运行产物及自动提交/推送逻辑。
