# AI4SCIENCE Codex 通用项目工具包

本目录是从 `01-Project/shiji-kb-main/shiji-kb-main` 提炼并迁移的通用项目管理、编程规范和 Codex 工作流资产。它是一个**可审阅、可选择性启用**的工具包，不会自动改变 `AI4SCIENCE/projectname` 或其中任何项目。

## 目录结构

```text
codex-project-kit/
├── AGENTS.template.md                 # 新项目根目录规则模板（审阅后复制）
├── README.md
├── MIGRATION-MANIFEST.md              # 来源→目标映射、排除项和验证记录
├── CHANGELOG.md / TODO.md
├── log/README.md
├── references/
│   ├── 通用经验迁移与Codex空白项目实施方案.md
│   └── claude-skill-spec.md            # 来源规范，仅作对照，不在 Codex 中直接加载
├── skills/
│   ├── methods/                        # 方法论：分解、迭代、质量、观测、融合、迁移等
│   ├── governance/                     # 项目管理、Git、日志、CHANGELOG、目录规则
│   └── templates/                      # 可复制的日志、反思和迁移记录模板
└── .codex/skills/                      # Codex 可触发 Skill（需安装到目标项目 .codex/skills）
    ├── project-governance/
    ├── quality-gate/
    ├── reflection-loop/
    ├── transfer-pilot/
    └── skill-authoring/
```

`references/source-derived/` 保存源文件的原始长篇版本，里面包含史记项目案例、Claude 命令和历史链接，只用于追溯和人工提炼，不能直接安装为通用规则。

## 如何用于一个空白项目

1. 先阅读 `references/通用经验迁移与Codex空白项目实施方案.md`，确认项目自己的目录、语言、测试和发布约束。
2. 将 `AGENTS.template.md` 复制为**目标项目根目录**的 `AGENTS.md`，再补充项目特有规则。不要把本文件直接放在 `projectname` 之外的聚合目录当作全局指令。
3. 将 `skills/methods/`、`skills/governance/` 中需要的文档复制到目标项目约定的 `skills/` 或 `docs/standards/`；保留来源和版本记录。
4. 将 `.codex/skills/<name>/` 复制到目标项目的 `.codex/skills/<name>/` 后，重新打开 Codex 会话并按触发描述使用。
5. 首次启用只建议安装 `project-governance`、`quality-gate`、`reflection-loop`、`transfer-pilot`；`skill-authoring` 在需要新增或演化 Skill 时再启用。
6. 在目标项目运行其真实的格式化、类型检查、测试和安全扫描命令；本工具包不伪造通过结果。

## 迁移边界

- 已迁移的是与项目无关的治理和方法文档，以及重新写成 Codex 格式的 Skill。
- 没有迁移源项目的 `.claude/skills/butler`、`map` 等操作型/领域型技能、自动提交或自动推送逻辑，也没有迁移源项目的 Wiki、数据和运行产物。
- `references/claude-skill-spec.md` 仅用于理解来源格式；Codex 实际加载的是 `.codex/skills/*/SKILL.md`。
- 任何项目特有经验应留在目标项目的 `docs/transfer/` 或对应领域目录，不能反向污染通用包。

## 维护规则

- 每次修改记录在目标项目的 `CHANGELOG.md` 或迁移日志中，注明来源文件、适配理由和验证命令。
- 新增规则必须有明确 owner、触发条件、输入/输出和失败边界；没有这些信息的内容只放在草稿或经验记录中。
- 迁移前检查路径、子进程、网络、凭据和写入范围；安全扫描结果只是证据之一，不是绝对安全证明。
