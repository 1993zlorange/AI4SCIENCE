# 工具包待办

- [ ] 由 AI4SCIENCE 各子项目 owner 审阅 `AGENTS.template.md` 并决定是否安装。
- [ ] 为目标项目补充真实的格式化、lint、类型检查、测试和安全扫描命令。
- [ ] 试点一个 Skill，记录触发准确性、失败边界和回滚证据。
- [ ] 清理或归档不再需要的 `references/source-derived/` 来源示例。

