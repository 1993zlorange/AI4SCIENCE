---
name: skill-authoring
description: 编写或演化一个可维护的 Codex Skill；适用于新增工作流、把经验固化为 Skill 或审查现有 Skill。
---

# Skill authoring

Skill 提案及演化记录使用本目录的 [中文空白模板](assets/output-template.md)。凡有文档输出，模板必须与 Skill 同目录维护。

1. 先读取项目 `AGENTS.md` 和相关方法/治理文档，确认 Skill 的唯一责任、触发边界、owner 和不迁移内容。
2. 在 `.codex/skills/<kebab-case-name>/SKILL.md` 使用短小、可执行的步骤；至少写清触发条件、前置读取、输入、输出、失败条件、回滚、权限边界、验证命令和最小示例。
3. 把确定性检查放脚本，把判断和协作放 Skill；脚本必须使用仓库相对路径或显式参数，不访问凭据、不执行动态代码、不隐式联网。
4. 对正常、边界、无效输入、依赖失败、取消/恢复、并发冲突和重复执行增加测试或可复核检查；所有脚本和内部链接必须存在。
5. 新 Skill 先小范围试点；按成功率、误触发率、失败类型、耗时和维护成本迭代、合并或淘汰。
6. 更新 README、CHANGELOG、来源映射和 owner；避免重复 Skill、无限追加规则和无 owner 的 TODO。

不把项目名、固定数据字段、业务质量指标、绝对路径或 Claude 专属命令写入通用 Skill；无法去除领域假设时转入项目专属目录。
