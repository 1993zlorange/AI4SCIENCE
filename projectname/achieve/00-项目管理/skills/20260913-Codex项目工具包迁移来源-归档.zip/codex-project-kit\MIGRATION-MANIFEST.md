# 迁移清单

来源：`01-Project/shiji-kb-main/shiji-kb-main`
目标：`01-Project/AI4SCIENCE/codex-project-kit`
日期：2026-09-11

## 已适配为通用文档

| 来源类别 | 目标目录 | 处理方式 |
| --- | --- | --- |
| `00-META-00/01/02/03/05/06/09/10/13` | `skills/methods/` | 提取通用方法，去除史记字段、固定指标和 Claude 专属执行方式 |
| `00-META-04/07/11/12` | `skills/methods/` | 新增通用的任务分解、可读性、数据可观测性和多源融合方法，去除领域示例与固定脚本 |
| `00-META-08_标注体系设计` | `skills/methods/00-META-08_标注与Schema设计.md` | 提取正交分类、消歧分层、Schema 版本迁移和 lint 验证原则，去除业务类型和样例数据 |
| `SKILL_10/10a/10b/10c/10d/10e/10f/10g` | `skills/governance/` | 提取项目管理、日志、Git、CHANGELOG、目录、Skill 工程和成本统计规则 |
| 相关模板 | `skills/templates/` | 新建 Codex 可复制的日志、反思和迁移记录模板 |

原始长篇文件逐一保存在 `references/source-derived/`，用于追溯，不作为默认规则加载。

本次重命名保留了源项目对应文件名：方法文件使用 `00-META-*`，治理文件使用 `SKILL_10*`，来源规范使用 `claude-skill-spec.md`。目录层级仍按 Codex 工具包职责区分。

## 已重设计为 Codex Skill

| 目标 Skill | 用途 |
| --- | --- |
| `.codex/skills/project-governance` | 范围、owner、任务、日志和交付证据 |
| `.codex/skills/quality-gate` | L1–L5 分层质量门禁 |
| `.codex/skills/reflection-loop` | 证据驱动反思和最小改进 |
| `.codex/skills/transfer-pilot` | 跨项目安全迁移和回滚 |
| `.codex/skills/skill-authoring` | Codex Skill 编写、试点和生命周期 |

## 本轮源 Skill 细化映射

| `shiji-kb-main` 来源 | 已写入的目标文件 | 可迁移的通用规则 |
| --- | --- | --- |
| `SKILL_W0_Butler总则`、`SKILL_W1_Butler探索与食物收集` | `.codex/skills/project-governance/SKILL.md`、`skills/governance/SKILL_10a_TODO和Issue管理.md` | 任务队列、优先级、去重、owner/锁、轮次状态、暂停条件和可追溯证据 |
| `SKILL_W2_Butler原子行动目录`、`SKILL_Butler多实例设计` | `project-governance`、`SKILL_10a`、`SKILL_10b` | 原子动作、单目标变更、前后检查、回滚、并发边界、幂等和追加式日志 |
| `SKILL_W3_Butler质量标准`、`SKILL_W4_Butler评估与检验`、`SKILL_W6_Butler离线质检` | `.codex/skills/quality-gate/SKILL.md`、`skills/methods/00-META-10_质量控制.md` | 分层质量门、红旗阻断、批处理复核、来源追溯、失败重试和风险分级 |
| `SKILL_W5_Butler反思与自改` | `.codex/skills/reflection-loop/SKILL.md`、`skills/methods/00-META-01_反思.md`、`00-META-06_SKILL优化与演化.md` | 反思触发器、根因分类、最多三轮改规则、最小试点和人工批准边界 |
| `.claude/skills/daily` | `skills/governance/SKILL_10b_每日工作日志维护.md`、`skills/templates/daily-log.md` | 缺失日志补记、事实/推测分离、按提交或运行证据回填、禁止借补记自动提交 |
| `.claude/skills/msg` | `skills/governance/SKILL_10c_Git代码版本管理规范.md` | 仅查看暂存差异、显式路径、提交消息预览、禁止隐式全量暂存和默认提交 |
| `.claude/skills/butler` 中的循环/暂停/锁机制 | `project-governance`、`quality-gate`、`reflection-loop` | 将自动循环改为显式轮次，由质量门和暂停条件控制，不自动执行外部写入 |

以下内容不进入通用 Skill：`enrich`、`map`、`quote` 的 Wiki 页面结构、史料字段、地图裁切、引文检索指标，以及任何固定项目路径、业务阈值和运行时专属命令。

## 明确不迁移

- 源项目 `.claude/skills/butler`、`map` 等依赖 Claude 运行时、领域数据或自动循环的操作技能。
- 已扫描出高风险动态子进程行为的地图脚本，以及自动 commit/push 授权。
- Wiki、原始数据、缓存、运行产物和项目专用配置。

## 验证记录

- Codex Skill frontmatter 与目录名一致：通过（5/5）。
- `projectname` 目录未写入或修改：通过。
- 目标工具包布局检查：未执行仓库专用检查器（AI4SCIENCE 当前不是可识别的 ScienceResearch 根目录）；已完成人工目录审计。
- 目标项目真实格式化、类型检查和测试：未运行（本次仅迁移文档/Skill，未改变产品代码）。
