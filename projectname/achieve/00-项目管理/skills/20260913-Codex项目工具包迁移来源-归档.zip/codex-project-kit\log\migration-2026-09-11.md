# 迁移记录：shiji-kb-main → AI4SCIENCE

日期：2026-09-11
目标目录：`E:/zl/01-Project/AI4SCIENCE/codex-project-kit`

## 改动

- 迁移 17 份来源方法/治理文档的原始副本到 `references/source-derived/`，并以 SHA-256 校验确认副本未被改写。
- 新建去领域化 `skills/methods/`、`skills/governance/` 和 `skills/templates/`。
- 新建 5 个 Codex Skill：`project-governance`、`quality-gate`、`reflection-loop`、`transfer-pilot`、`skill-authoring`。
- 新建 `AGENTS.template.md`、`README.md`、`MIGRATION-MANIFEST.md`、`CHANGELOG.md` 和 `TODO.md`。
- 将 35 个有源文件对应关系的文件名恢复为 `shiji-kb-main` 原名；Codex 新增 Skill、模板和管理文件保持适配名。

## 未迁移

源项目 `.claude/skills` 操作脚本、Wiki、数据、运行产物以及自动提交/推送逻辑没有进入目标包；相关原因见 `MIGRATION-MANIFEST.md`。

## 验证

- 5 个 Codex Skill 的目录名与 frontmatter `name` 一致。
- 可安装文档未发现危险删除、强制推送、动态执行或隐式联网指令。
- `AI4SCIENCE/projectname` 未写入或修改。
- AI4SCIENCE 当前未被仓库专用布局检查器识别，因此未宣称该检查通过；本次未改变产品代码，未运行产品测试。
- 旧适配路径残留检查：通过；源副本 SHA-256 检查：通过（17/17）；布局检查器结果：不适用（目标不是可识别的 ScienceResearch 根目录）。
