# 通用经验迁移与 Codex 空白项目实施方案

**文档状态**：可执行方案草案  
**来源项目**：`01-Project/shiji-kb-main/shiji-kb-main`  
**目标**：把本项目中可复用的项目管理、Agent 协作、质量控制和知识沉淀经验迁移到其他软件、数据或研究项目，并在 Codex 中形成可执行的空白项目基线。

## 1. 迁移结论

本项目的经验应拆成三层，不应把整个 `skills/` 或 `.claude/` 目录原样复制：

1. **通用治理层**：项目启动检查、范围控制、Git 安全、文件组织、日志、反思、质量门、技能生命周期。这些内容可以迁移到大多数项目。
2. **可配置工程层**：冷启动、试点、错误模式统计、质量分级、任务队列、锁、修订历史。这些内容保留流程和接口，替换领域参数。
3. **史记领域层**：古籍实体符号、`pn`、`event_ids`、章节类型、谭图地图、史记引文规则等，只留在史记项目或作为独立领域插件。

迁移后的 Codex 项目应遵循以下原则：

- `AGENTS.md` 负责项目级规则和安全边界。
- `.codex/skills/` 负责可触发的操作型 Skill；`skills/` 负责方法论和领域规范。
- 脚本负责确定性检查和批处理，Skill 负责决策流程和人机协作。
- 所有批量修改默认先预览，显式 `--write` 才写入。
- 不自动 commit、push、删除、覆盖或调用外部付费服务。
- 每次重要变化都要能追溯到输入、规则、脚本、验证结果和操作者。

## 2. 可直接迁移、适配迁移和禁止直接迁移

### 2.1 可直接迁移的文件内容

以下文件可以作为通用方法文档迁移。建议复制后去掉史记示例，并改成新的项目名、路径和指标；“直接迁移”指内容结构和方法可以复用，不代表文件可以完全不改名、不改路径。

| 来源文件 | 迁移后的建议文件 | 用途 |
|---|---|---|
| `skills/00-META-00_好东西都是总结出来的.md` | `skills/methods/knowledge-extraction.md` | 从案例、错误和日志中提炼通用规律 |
| `skills/00-META-01_反思.md` | `skills/methods/reflection-loop.md` | 反思任务的输入、执行、输出和验证 |
| `skills/00-META-02_迭代工作流.md` | `skills/methods/iterative-delivery.md` | 冷启动、模式积累、收敛和终态验证 |
| `skills/00-META-03_冷启动.md` | `skills/methods/cold-start.md` | 新工序从零开始的启动流程 |
| `skills/00-META-05_知识作为上下文压缩.md` | `skills/methods/context-compression.md` | 把长上下文压缩为可复用知识资产 |
| `skills/00-META-06_SKILL优化与演化.md` | `skills/methods/skill-lifecycle.md` | Skill 从日志产生、试点、演化和淘汰 |
| `skills/00-META-09_Agent提示词工程.md` | `skills/methods/agent-task-design.md` | 任务目标、约束、方法、验证、输出五层结构 |
| `skills/00-META-10_质量控制.md` | `skills/methods/quality-control.md` | L1–L5 质量检查体系和脚本契约 |
| `skills/00-META-13_技能迁移.md` | `skills/methods/skill-transfer.md` | 直接复用、适配、重设计和试点迁移 |
| `skills/SKILL_10_项目管理.md` | `skills/governance/project-management.md` | TODO、Issue、日志、CHANGELOG 和交付管理 |
| `skills/SKILL_10b_每日工作日志维护.md` | `skills/governance/daily-log.md` | 日志时间边界、统计和意义总结 |
| `skills/SKILL_10c_Git代码版本管理规范.md` | `skills/governance/git-safety.md` | Git 操作安全和提交前检查 |
| `skills/SKILL_10d_CHANGELOG编写规范.md` | `skills/governance/changelog.md` | 变更分类、日期组织和证据链接 |
| `skills/SKILL_10e_文件组织与目录结构.md` | `skills/governance/repository-layout.md` | 新文件放置和目录职责决策树 |
| `skills/SKILL_10f_Skill的提炼与转化.md` | `skills/governance/skill-authoring.md` | Skill 结构、长度、脚本关联和维护要求 |
| `skills/help/claude-skill-spec.md` | `docs/standards/skill-package-spec.md` | Skill 包的元数据、资源和触发描述规范 |

### 2.2 只迁移框架、必须适配的内容

- 质量等级：保留“分级、指标、升级路径”，重新定义业务指标和阈值。
- Butler 队列：保留“领取任务、声明目标、冲突检查、执行、记账、释放锁”，替换任务类型。
- `record_revision.py`：保留修订历史和 recent 索引，替换页面模型。
- `compute_quality.py`：保留 `--dry-run`、返回码和统计报告，替换质量计算逻辑。
- `wiki/memory/`：保留“索引 + 独立规则文件 + 置信度”，替换领域规则。
- 事件和关系 Schema：保留 `id/time/participants/location/source` 等通用字段，删除史记字段，增加目标项目字段。

### 2.3 不得直接迁移的内容

- `.claude/skills/butler` 的自动循环、自动 commit 和自动 push 授权。
- `pn`、`event_ids`、18 类古籍实体标记、全角引号规则。
- 本纪、世家、列传、表、书等史记章节假设。
- 谭其骧地图、史记引文搜索模式和历史时期参数。
- `/home/baojie/...` 等绝对路径。
- `bash`、`awk`、`date -d`、`python3`、`fcntl/flock` 等不可移植假设。
- 固定的“错误率 3%”“每章 15–40 个事件”等史记经验数字。它们必须成为可配置参数，不能当作通用标准。

## 3. 空白项目推荐目录

```text
project/
├── AGENTS.md                         # 项目级规则，Codex 首要读取
├── .codex/
│   └── skills/                       # 可触发的 Codex Skill 包
│       ├── project-governance/
│       │   └── SKILL.md
│       ├── quality-gate/
│       │   └── SKILL.md
│       ├── reflection-loop/
│       │   └── SKILL.md
│       ├── skill-authoring/
│       │   └── SKILL.md
│       ├── transfer-pilot/
│       │   └── SKILL.md
│       └── git-safety/
│           └── SKILL.md
├── skills/
│   ├── methods/                      # 通用方法论
│   ├── governance/                   # 项目治理规则
│   ├── domain/                       # 当前项目领域规则
│   ├── references/                   # 长文档、词表、标准
│   └── templates/                    # 报告、日志、迁移模板
├── scripts/
│   ├── validation/                   # lint、validate、cross_validate
│   ├── generation/                   # 报告和数据生成
│   ├── reflection/                   # 错误模式和反思报告
│   └── workflows/                   # 有界工作流编排
├── tests/
│   ├── unit/
│   ├── integration/
│   └── fixtures/
├── data/                             # 正式数据资产
├── labs/                             # 原型、试验和未定稿材料
├── docs/
│   ├── decisions/                    # ADR、决策和开放问题
│   ├── transfer/                     # 技能迁移记录
│   └── reports/                      # 阶段报告和验收证据
├── logs/
│   ├── daily/                        # 每日工作日志
│   ├── runs/                         # 脚本和 Agent 运行记录
│   ├── reflections/                  # 反思报告
│   └── memory/                       # 高置信度规则和索引
├── CHANGELOG.md
├── TODO.md
└── README.md
```

## 4. 空白项目 `AGENTS.md` 基线模板

新项目建立后，应把下面规则写入根目录 `AGENTS.md`，再根据项目补充领域约束：

```markdown
# AGENTS.md

## 项目目标

- 用一句话说明项目要交付什么。
- 写明当前工作范围和明确不做的内容。

## 启动检查

首次工作前必须：
1. 读取本文件和适用的 `.codex/skills/*/SKILL.md`。
2. 检查目录、依赖和工作区状态。
3. 区分用户事实、项目决策、推断和未知事项。
4. 识别本次任务的输入、输出、验证方式和失败边界。

## 数据安全

- 原始输入只读；批量处理不得覆盖已有人工内容。
- 写入前先执行预览或 dry-run。
- 不得使用 `git reset --hard`、`git checkout --`、`git restore` 或 force push。
- 不得擅自执行 `git add .`、`git add -A`、commit 或 push。
- 任何删除、覆盖、发布、付费、凭据和外部写入操作都要显式确认。

## 修改流程

1. 读取相关文件和已有测试。
2. 先提出最小变更范围。
3. 使用补丁或专用脚本修改。
4. 运行适用的 L1–L5 检查。
5. 查看 diff，报告修改文件、验证结果和未解决风险。

## 文件放置

- 正式文档放 `docs/`。
- 实验和草稿放 `labs/`。
- 正式数据放 `data/`。
- 稳定脚本放 `scripts/`。
- 运行日志放 `logs/`。
- 通用规则放 `skills/governance/` 或 `skills/methods/`。
- 领域规则放 `skills/domain/`。

## 交付标准

- 每项 Must 需求都有实现、测试或明确阻塞记录。
- 每个脚本都有 `--help`、输入、输出、返回码和错误说明。
- 每项重要变更都能追溯到规则、脚本、测试和证据。
- 报告必须区分“已实现”“自动化验证通过”“人工观察”“用户验收”。
```

## 5. Codex Skill 包模板

每个可触发 Skill 建议采用以下结构：

```text
.codex/skills/<skill-name>/
├── SKILL.md
├── references/
├── scripts/
└── assets/
```

`SKILL.md` 模板：

```markdown
---
name: quality-gate
description: >
  用于运行项目质量检查、验证数据完整性并生成失败报告。
  当任务涉及批量修改、迁移、发布或验收时必须使用。
---

# Quality Gate

## 适用范围

说明何时触发、何时不触发，以及需要的前置条件。

## 核心流程

1. 读取项目规则和变更范围。
2. 执行 L1 文件/文本完整性检查。
3. 执行 L2 格式检查。
4. 执行 L3 Schema 检查。
5. 执行 L4 业务逻辑检查。
6. 执行适用的 L5 跨模块一致性检查。

## 工具与脚本

列出脚本路径、参数、预期返回码和输出文件。

## 失败处理

发现 ERROR 时停止后续高层检查；只报告定位、原因、建议修复和下一步。

## 输出格式

输出 PASS/FAIL、统计数字、失败文件、行号、验证环境和残余风险。
```

Skill 编写要求：

- frontmatter 至少包含 `name` 和 `description`。
- `description` 必须包含触发场景和边界。
- 正文优先保留核心流程，详细内容放 `references/`。
- 总长度建议 200–500 行。
- 至少关联一个确定性脚本或检查命令。
- 必须包含执行前、执行中、执行后的检查清单。
- 不得在 description 中隐藏网络请求、写入、发布或外部副作用。

## 6. 通用工作流

### 6.1 会话启动

1. 读取 `AGENTS.md`。
2. 读取与任务匹配的 Skill。
3. 查看目标文件、测试和目录边界。
4. 记录当前状态和未解决问题。
5. 给出本轮目标、范围和验证方法。

### 6.2 功能或缺陷修改

1. 明确目标和验收标准。
2. 搜索相关实现和测试。
3. 先运行现有测试，记录基线。
4. 进行最小修改。
5. 运行定向测试，再运行受影响的回归测试。
6. 查看 diff，确认没有覆盖无关修改。
7. 汇报变更、验证、风险和未执行项。

### 6.3 冷启动新工序

1. 定义 What、Why、输入、输出、粒度和成功标准。
2. 人工处理 3–10 个样本，记录判断依据和困难案例。
3. 编写 5–15 条最小规则。
4. 对 3–5 个试点执行粗处理。
5. 统计遗漏、误报、格式错误和重复失败模式。
6. 让 Agent 生成反思报告，由人决定规则是否升级。
7. 应用修正规则重新处理试点。
8. 达到项目定义的质量门后再扩展全量。

### 6.4 反思循环

每轮必须产生：

- 输入样本和版本；
- 已知规则；
- 错误案例和统计；
- 根因分析；
- 规则修改建议；
- 人工采纳/拒绝决定；
- 修正后的验证结果；
- 下一轮进入条件或停止理由。

### 6.5 每日记录和 CHANGELOG

- `logs/daily/YYYY-MM-DD.md` 记录当天目标、完成结果、验证和阻塞。
- `logs/runs/*.jsonl` 记录脚本、参数、时间、返回码和产物。
- `CHANGELOG.md` 只写高层变更，并链接详细日志。
- 不把没有结果的活动描述成完成事项。

## 7. 脚本统一契约

所有迁移到新项目的脚本应满足：

| 项目 | 要求 |
|---|---|
| 参数 | 使用 `argparse` 或等价解析器，提供 `--help` |
| 写入 | 默认 dry-run，使用 `--write` 才修改 |
| 路径 | 使用仓库相对路径或显式配置，不写死用户目录 |
| 输出 | 输出文件、统计、错误位置和下一步建议 |
| 返回码 | 成功为 0，发现 ERROR 为 1，参数/环境错误为 2 |
| 安全 | 固定脚本路径、白名单参数、禁止 shell 拼接用户输入 |
| 幂等性 | 重复运行不重复追加、不破坏已有内容 |
| 记录 | 记录运行时间、版本、输入摘要和输出摘要 |
| 测试 | 至少有正常、空输入、错误输入和重复运行测试 |

建议的检查命名：

```text
lint_*            单一格式或语法检查
validate_*        数据完整性和业务逻辑检查
cross_validate_*  跨文件、跨模块一致性检查
generate_*        报告或中间产物生成
record_*          变更、运行或修订历史记录
```

## 8. 迁移实施计划

### 阶段 0：盘点

- 列出源项目所有 Skill、脚本、模板、日志和外部路径。
- 给每项标记 `通用`、`可配置`、`领域专用`、`废弃/待审计`。
- 记录缺失依赖、平台假设、网络调用和写入副作用。

**产物**：`docs/transfer/inventory.md`。

### 阶段 1：建立空白项目基线

- 创建推荐目录。
- 写入 `AGENTS.md`。
- 建立 `CHANGELOG.md`、`TODO.md` 和日志目录。
- 建立 Skill 模板和脚本契约。

**通过条件**：新项目可以完成启动检查，且没有史记专用路径。

### 阶段 2：迁移治理和方法 Skill

优先迁移：

- `project-governance`
- `git-safety`
- `quality-gate`
- `reflection-loop`
- `skill-authoring`
- `transfer-pilot`

**通过条件**：每个 Skill 都有明确触发描述、失败边界和最小示例。

### 阶段 3：迁移脚本和日志机制

- 将 Linux/Bash 脚本改为 Python 或 PowerShell 可调用脚本。
- 增加 `--dry-run`、`--write`、结构化输出和退出码。
- 为重要写入建立 JSONL 修订历史。
- 为并发任务建立目标锁和超时清理。

**通过条件**：脚本在目标操作系统上可重复运行，第二次运行不会产生重复数据。

### 阶段 4：三到五个样本试点

- 选择简单、中等、复杂样本，并覆盖主要输入类型。
- 执行粗处理和 L1–L3 检查。
- 人工抽查，记录错误和边界案例。
- 反思后修改 Skill、词表、Schema 或脚本。
- 对比修正前后质量，不以单次 Agent 输出作为验收依据。

### 阶段 5：扩大范围

只有满足以下条件才能全量执行：

- 试点错误模式已归类；
- 高优先级错误已修正；
- L1–L3 检查稳定通过；
- 人工抽查达到项目设定阈值；
- 所有批量写入均可回溯或恢复；
- 领域负责人确认新的规则和 Schema。

### 阶段 6：维护和淘汰

- 每月检查失效路径、失效链接和脚本可执行性。
- 每季度审查 Skill 是否过时、过长或重复。
- 重复出现的失败模式才升级为规则。
- 项目专用经验回到 `docs/transfer/`，不要污染通用 Skill。

## 9. 质量门和验收清单

### L1 文件和文本完整性

- [ ] UTF-8 编码可读。
- [ ] 必需文件存在。
- [ ] 原始输入哈希或内容未改变。
- [ ] 输出没有意外截断、乱码或空文件。

### L2 格式完整性

- [ ] Markdown、JSON、YAML 可解析。
- [ ] 标记、括号、代码块和表格边界闭合。
- [ ] 文件名、链接和引用路径有效。

### L3 数据完整性

- [ ] 必填字段非空。
- [ ] 枚举值合法。
- [ ] ID 唯一且引用目标存在。
- [ ] 批量导入没有覆盖已有人工内容。

### L4 业务逻辑

- [ ] 时间、状态、数量和依赖关系合理。
- [ ] 失败输入能被识别并返回可定位错误。
- [ ] 重复执行不会造成重复记录。

### L5 跨模块一致性

- [ ] 文档、代码、测试和配置中的名称一致。
- [ ] 索引、注册表、缓存和源数据一致。
- [ ] 变更记录能够指向实际产物和验证证据。

### 交付验收

- [ ] 所有 Must 项都有任务、代码、文档或明确阻塞。
- [ ] 未执行、未授权和外部副作用步骤被明确标记。
- [ ] 自动化验证、人工观察和用户验收没有混为一谈。
- [ ] 没有自动 commit、push、删除或覆盖行为。
- [ ] 迁移报告包含剩余风险、开放决策和下一步动作。

## 10. 推荐的首批文件清单

空白项目第一阶段只需要建立以下文件，不要一次性复制史记项目的全部 145 个 Skill：

```text
AGENTS.md
README.md
CHANGELOG.md
TODO.md
skills/methods/cold-start.md
skills/methods/reflection-loop.md
skills/methods/iterative-delivery.md
skills/methods/quality-control.md
skills/methods/skill-transfer.md
skills/governance/git-safety.md
skills/governance/repository-layout.md
skills/governance/skill-authoring.md
skills/templates/daily-log.md
skills/templates/reflection-report.md
skills/templates/transfer-log.md
.codex/skills/project-governance/SKILL.md
.codex/skills/quality-gate/SKILL.md
.codex/skills/reflection-loop/SKILL.md
.codex/skills/transfer-pilot/SKILL.md
scripts/validation/lint_project.py
scripts/validation/validate_links.py
scripts/validation/validate_schema.py
scripts/reflection/build_error_report.py
scripts/workflows/run_quality_gate.py
logs/memory/MEMORY.md
```

## 11. 迁移前人工确认事项

- 目标项目是否允许 Agent 修改正式数据？
- 哪些目录是原始输入，只读还是可生成？
- 是否允许网络访问、凭据访问、发布和远程写入？
- 哪些质量指标由领域专家定义？
- 哪些 Skill 需要人工审批才能升级为项目规则？
- 项目是否使用 Git；若不使用，如何保存版本和恢复点？

这些问题没有答案时，默认采用最保守模式：只读分析、dry-run、生成报告和补丁，不执行外部写入。

## 12. 方案来源与边界

本方案依据以下项目资产整理：

- `CLAUDE.md`：项目启动检查、Git 安全、原始数据保护和文件组织。
- `skills/00-META-01`、`02`、`03`、`06`、`09`、`10`、`13`：反思、迭代、冷启动、Skill 演化、提示词、质量控制和迁移。
- `skills/SKILL_10`、`10b`、`10c`、`10d`、`10e`、`10f`：项目管理、日志、Git、CHANGELOG、目录和 Skill 工程化。
- `.claude/skills/*`：操作型 Skill 的触发、脚本调用、锁、记账和验证模式。
- `wiki/memory`、`wiki/logs`、`wiki/scripts`：运行记忆、审计日志、修订历史、质量脚本和并发机制。

本方案不把扫描结果当作绝对安全证明。迁移前仍应逐个审计 Skill、脚本、子进程调用、网络访问、凭据访问和文件写入范围。

## 13. shiji-kb-main 项目管理经验：精炼总结与证据

本节只提取可迁移的管理机制；史记项目中的标签名称、时间边界、文案风格和领域指标仍需参数化。证据来自源项目的规则文件和已记录的工作流，不等同于对所有运行结果的独立审计。

1. **用三本账形成闭环**：Issue 是需求入口，TODO 是执行抓手，每日日志是项目记忆；变更完成后回写 Issue 和 CHANGELOG。证据：[SKILL_10_项目管理.md](../skills/SKILL_10_项目管理.md)（第 15、32–56、60–64 行）。迁移时固定保留“需求账、任务账、证据账”三层，不以聊天记录代替项目记录。

2. **先分类，再决定处理路径**：`REF`、`RES`、`DOC`、`HELP`、`QA`、`FEAT`、`BUG` 七类 Issue 各有处理动作和关闭条件。证据：[SKILL_10a_TODO和Issue管理.md](../skills/SKILL_10a_TODO和Issue管理.md)（第 15、31–48、88–105 行）。迁移时保留分类决策树，按新项目改写标签。

3. **Issue 必须拆成可验证的 TODO**：功能或缺陷 Issue 要关联一个或多个 TODO，全部 TODO 完成后才能关闭 Issue；复杂度决定拆分数量。证据：[SKILL_10a_TODO和Issue管理.md](../skills/SKILL_10a_TODO和Issue管理.md)（第 139–146、231–263 行）。迁移时要求每个 TODO 有 `relatedIssue`、完成标准和验证证据。

4. **限制并行量和任务粒度**：同一时间只保留一个 `in_progress` TODO，单项任务控制在 1–4 小时，完成后立即更新状态。证据：[SKILL_10_项目管理.md](../skills/SKILL_10_项目管理.md)（第 192–220 行）。这样可以降低上下文切换和“任务已做但状态未更新”的风险。

5. **日志记录结果、数字和价值**：日志不仅写做过什么，还要写为什么做、影响是什么，并用 Git 统计核对自动摘要。源项目明确记录过自动统计“8 个章节”而实际 Git 结果为“44 个章节、174 个文件”的纠偏案例。证据：[SKILL_10b_每日工作日志维护.md](../skills/SKILL_10b_每日工作日志维护.md)（第 163–203、294–328 行）。迁移时所有关键数字必须能回溯到命令、脚本或文件。

6. **把能力价值放在活动数量之前**：项目日志采用“新能力 > 流程改进 > 质量提升 > 文档完善”的优先顺序。证据：[SKILL_10b_每日工作日志维护.md](../skills/SKILL_10b_每日工作日志维护.md)（第 294–319 行）。迁移时可增加业务价值、风险和成本评分，但应保留“价值优先”原则。

7. **分离不同受众的变更记录**：CHANGELOG 面向用户和决策者，每日日志面向开发者，提交记录面向代码审计；CHANGELOG 条目链接详细日志。证据：[SKILL_10d_CHANGELOG编写规范.md](../skills/SKILL_10d_CHANGELOG编写规范.md)（第 17–44、351–405 行）。迁移时不要把技术流水账复制到对外变更说明中。

8. **Git 安全优先于操作便利**：禁止未经授权的破坏性恢复、批量 add、force push 和自动提交；修改前检查工作区和 diff。源项目还记录了两次 `git checkout` 覆盖工作成果的事故。证据：[SKILL_10c_Git代码版本管理规范.md](../skills/SKILL_10c_Git代码版本管理规范.md)（第 17–79、185–244 行）、[CLAUDE.md](../CLAUDE.md)（第 10–60 行）。Codex 项目应默认只读检查、显式授权写入。

9. **按责任和生命周期放置文件**：正式文档、实验材料、数据、脚本、运行日志、归档和 Skill 分目录管理，并用决策树判断新文件归属。证据：[SKILL_10e_文件组织与目录结构.md](../skills/SKILL_10e_文件组织与目录结构.md)（第 9–36、305–344 行）。迁移时每个新文件都应有目录责任、生命周期和发布边界。

10. **Skill 作为可维护的软件资产**：Skill 要有触发条件、快速开始、工具/脚本、前中后检查清单，并定期检查长度、链接、使用频率和重复内容。证据：[SKILL_10f_Skill的提炼与转化.md](../skills/SKILL_10f_Skill的提炼与转化.md)（第 35–43、84–123、157–175 行）。迁移到 Codex 时将操作型 Skill 放入 `.codex/skills/`，方法论放入 `skills/`。

11. **先试点再扩大**：冷启动先人工处理样本，再做 3–5 个试点，统计遗漏、误报和重复失败；通过 L1–L3 检查和人工阈值后才允许全量。证据：[通用经验迁移与Codex空白项目实施方案.md](通用经验迁移与Codex空白项目实施方案.md)（第 252–274、350–367 行）。这是把经验变成规则前的最低质量门。

12. **把成本和时间纳入管理反馈**：源项目将 AI 成本、有效工作时长、会话识别和报告留存作为效率分析对象。证据：[SKILL_10g_项目成本与时间统计.md](../skills/SKILL_10g_项目成本与时间统计.md)（第 18–69 行）。迁移到 Codex 时将 Claude 专用字段替换为模型、工具、运行时间和资源成本。

## 14. 开发者完整工作流程与调用顺序

### 14.1 总体原则

开发者每次只处理一个有明确验收标准的 TODO；流程按“治理 → 设计 → 基线 → 实现 → 验证 → 记账 → 复盘 → 交付”推进。文件是调用入口，Skill 名称只是能力标签。任何输入不完整、规则冲突、质量门失败、越界修改或未授权副作用都必须停在当前阶段并记录原因。

### 14.2 一次任务的逐步调用表

| 阶段 | 先调用的 Codex 文件（目标项目） | shiji 原项目对应文件 | 执行动作与产物 | 通过/停止条件 |
|---|---|---|---|---|
| 0. 任务进入 | `AGENTS.md`、`README.md`、`.codex/skills/project-governance/SKILL.md`、`skills/methods/00-META-00_好东西都是总结出来的.md` | `CLAUDE.md`、`README.md`、`skills/00-META-00_好东西都是总结出来的.md` | 读取规则、项目边界、目录责任和已有改动；写一段范围摘要 | 找到项目根和适用规则；否则停止，不猜路径 |
| 1. 分类建账 | `skills/governance/SKILL_10_项目管理.md`、`skills/governance/SKILL_10a_TODO和Issue管理.md`、`.codex/skills/project-governance/SKILL.md` | `skills/SKILL_10_项目管理.md`、`skills/SKILL_10a_TODO和Issue管理.md` | 将请求分类为 Issue，写 Must/Should/边界/验收；拆成可验证 TODO，填写 `relatedIssue` | 每个 TODO 有完成标准、验证命令、目标文件；否则不进入实现 |
| 2. 冷启动或迁移 | 新工序：`skills/methods/00-META-03_冷启动.md`；复用规则：`.codex/skills/transfer-pilot/SKILL.md` + `skills/methods/00-META-13_技能迁移.md` | `skills/00-META-03_冷启动.md`、`skills/00-META-13_技能迁移.md` | 盘点依赖、平台、路径、权限和副作用；选择直接复用/适配/重设计/不迁移；建立试点记录 | 迁移决策和回滚方式已写入 `skills/templates/transfer-log.md`；否则停止迁移 |
| 3. 任务分解 | `skills/methods/00-META-04_柳叶刀方法.md`（按需迁移）、`skills/methods/00-META-09_Agent提示词工程.md`；若有架构变更再读项目 `docs/architecture.md` 或 `docs/ADR/` | `skills/00-META-04_柳叶刀方法.md`、`skills/00-META-09_Agent提示词工程.md` | 把任务拆成可独立验证的子任务，决定规则/脚本/模型；写输入、输出、失败边界和副作用 | 每个子任务有唯一责任和验证方式；存在隐含需求时回到第 1 阶段 |
| 4. 基线与安全 | `.codex/skills/quality-gate/SKILL.md`、`skills/governance/SKILL_10c_Git代码版本管理规范.md`、`AGENTS.md` | `skills/00-META-10_质量控制.md`、`skills/SKILL_10c_Git代码版本管理规范.md`、`CLAUDE.md` | 运行最小现有检查，记录修改前结果；查看 `git status/diff`；确认不覆盖用户改动 | 基线结果可复现且工作区边界清楚；检查失败先记录，不得假装通过 |
| 5. 最小实现 | 适用领域 Skill；`skills/methods/00-META-07_可读性.md`（按需迁移）；数据任务加 `skills/methods/00-META-11_数据体感培养.md`（按需迁移） | 对应 `skills/SKILL_*`、`skills/00-META-07_可读性.md`、`skills/00-META-11_数据体感培养.md` | 只修改已声明文件；批量写入先 dry-run；保留中间产物、来源和 `run_id`（适用时） | 产物落在责任目录，脚本可重复运行；越界或需要新依赖时暂停审批 |
| 6. 条件数据处理 | 上下文复用：`skills/methods/00-META-05_知识作为上下文压缩.md`；标注：`skills/methods/00-META-08_标注体系设计.md`（按需迁移）；多源：`skills/methods/00-META-12_数据融合.md`（按需迁移） | `skills/00-META-05_知识作为上下文压缩.md`、`skills/00-META-08_标注体系设计.md`、`skills/00-META-12_数据融合.md` | 只在重复查询、标注 Schema 或多源冲突真实存在时启用；保留来源、置信度、冲突和人工覆盖 | 条件不满足则跳过，不为小任务强行建图谱/标注体系/融合管线 |
| 7. 定向验证与质量门 | `.codex/skills/quality-gate/SKILL.md`、`skills/methods/00-META-10_质量控制.md` | `skills/00-META-10_质量控制.md`、`skills/SKILL_10f_Skill的提炼与转化.md` | 先跑受影响测试，再按 L1→L2→L3→L4→适用 L5；保留命令、退出码和输出 | ERROR 阻断；WARNING 必须有处置；未执行项明确标为未执行 |
| 8. 迭代收敛（条件返工） | `skills/methods/00-META-02_迭代工作流.md` | `skills/00-META-02_迭代工作流.md` | 质量门发现覆盖不足或错误模式时，按覆盖→模式积累→收敛→终态验证返工；完成后回到第 7 阶段 | 达到项目验收阈值才继续；禁止用固定百分比代替项目验收 |
| 9. 变更审查与记账 | `skills/governance/SKILL_10b_每日工作日志维护.md`、`skills/governance/SKILL_10d_CHANGELOG编写规范.md`、`skills/governance/SKILL_10g_项目成本与时间统计.md`、`skills/templates/daily-log.md` | `skills/SKILL_10b_每日工作日志维护.md`、`skills/SKILL_10d_CHANGELOG编写规范.md`、`skills/SKILL_10g_项目成本与时间统计.md` | 复查 diff/status；更新 TODO/Issue、`logs/daily/`、`logs/runs/`、CHANGELOG；记录时间、模型/工具和成本 | 数字可回溯到命令或文件，日志与代码事实一致；不一致则回到第 7 阶段 |
| 10. 反思与规则演化 | 失败或重复错误：`.codex/skills/reflection-loop/SKILL.md`、`skills/methods/00-META-01_反思.md`、`skills/templates/reflection-report.md`；规则升级再加 `.codex/skills/skill-authoring/SKILL.md`、`skills/methods/00-META-06_SKILL优化与演化.md` | `skills/00-META-01_反思.md`、`skills/00-META-06_SKILL优化与演化.md`、`skills/SKILL_10f_Skill的提炼与转化.md` | 区分事实/推测/意见，定位需求、流程、规则、实现或环境偏差；先小范围试点，人工批准后改 Skill | 单次成功不能升级规则；没有试点证据或 owner 时只记录建议 |
| 11. 交付与发布 | `.codex/skills/quality-gate/SKILL.md`、`AGENTS.md`、`CHANGELOG.md`；提交准备时读 `skills/governance/SKILL_10c_Git代码版本管理规范.md` | `.claude/skills/msg/SKILL.md`、`skills/SKILL_10c_Git代码版本管理规范.md`、`skills/SKILL_10d_CHANGELOG编写规范.md` | 输出改动路径、验证证据、未执行项、残余风险和下一步；commit/push/发布先预览再确认 | 未获明确授权不得 commit、push、删除、覆盖、联网写入或发布 |

### 14.3 文件调用的最短顺序（空白 Codex 项目）

```text
AGENTS.md + README.md
  → .codex/skills/project-governance/SKILL.md
  → skills/governance/SKILL_10_项目管理.md + SKILL_10a_TODO和Issue管理.md
  → skills/methods/00-META-03_冷启动.md（新工序）或 .codex/skills/transfer-pilot/SKILL.md + skills/methods/00-META-13_技能迁移.md（迁移）
  → skills/methods/00-META-04_柳叶刀方法.md + skills/methods/00-META-09_Agent提示词工程.md（按需迁移 04）
  → .codex/skills/quality-gate/SKILL.md + skills/methods/00-META-10_质量控制.md（基线）
  → 领域 Skill + skills/methods/00-META-07_可读性.md（数据任务加 skills/methods/00-META-11_数据体感培养.md）
  → skills/methods/00-META-02_迭代工作流.md（需要多轮收敛时）
  → .codex/skills/quality-gate/SKILL.md（定向检查与 L1–L5）
  → skills/governance/SKILL_10b_每日工作日志维护.md + skills/governance/SKILL_10d_CHANGELOG编写规范.md + skills/governance/SKILL_10g_项目成本与时间统计.md（日志、变更、成本）
  → .codex/skills/reflection-loop/SKILL.md + skills/methods/00-META-01_反思.md（失败或重复错误时）
  → skills/methods/00-META-06_SKILL优化与演化.md + .codex/skills/skill-authoring/SKILL.md（人工批准后演化）
  → 用户明确授权后才调用 skills/governance/SKILL_10c_Git代码版本管理规范.md 执行提交/发布
```

上面所有 `skills/...` 路径均指目标项目中的迁移后文件。当前 `codex-project-kit` 已预置 `00/01/02/03/05/06/09/10/13`；`04/07/08/11/12` 尚属按需文件，首次使用前必须调用 `.codex/skills/transfer-pilot/SKILL.md`，从 shiji 源文件建立 `references/source-derived/` 副本，完成试点后再提升到 `skills/methods/`。不得直接依赖 shiji 的绝对路径。

### 14.4 shiji-kb-main 原子轮次的文件级调用

源项目 `/butler` 每轮只做一个原子动作，文件级顺序为：

```text
.claude/skills/butler/SKILL.md
  → skills/SKILL_W0_Butler总则.md + wiki/logs/butler/round_counter.txt + queue.md
  → wiki/scripts/butler/claim_round.py --check-only
  → （超反思间隔时）skills/SKILL_W5_Butler反思与自改.md
  → wiki/scripts/butler/claim_round.py
  → skills/SKILL_W1_Butler探索与食物收集.md
  → wiki/scripts/butler/lock_manager.py set-page/check-page
  → skills/SKILL_W2_Butler原子行动目录.md + 具体动作 Skill
  → skills/SKILL_W3_Butler质量标准.md + SKILL_W4_Butler评估与检验.md
  → wiki/scripts/butler/record_action.py
  → wiki/scripts/butler/release_round.py（fail/skip 也必须调用）
```

动作型 Skill 的内部顺序也必须显式记录。例如 `.claude/skills/enrich/SKILL.md` 是“诊断 → 确定目标档 → `/quote` 补引文 → 写散文 → 加节 → `/map` 补图 → `compute_quality.py` 验证 → `record_revision.py` 记账”；`.claude/skills/daily/SKILL.md` 和 `.claude/skills/msg/SKILL.md` 只生成日志或提交草稿，不执行 commit。

### 14.5 Codex 与原 `/butler` 的边界

原 `/butler` 授权自动循环、自动 `git add` 和周期性 commit/push，不能原样迁移。Codex 只复用“单轮原子任务 → 锁与冲突检查 → 评估 → 记账 → 释放锁”的控制结构；所有 commit、push、删除、覆盖、发布、凭据访问和外部写入统一采用“预览 → 明确确认 → 执行 → 再验证”。

## 15. 00-META 经验的优化评估与通用化结论

### 15.1 逐项判定

| META | 是否通用 | 可迁移的核心经验 | 优化后用法与边界 | 证据 |
|---|---|---|---|---|
| `00` 总结与自举 | 是 | OTF（边做边总结）、JIT（小步交付）、Bootstrap（人工→脚本→Skill→自动化） | 作为所有项目的知识沉淀总则；禁止把“自动化率 99%”当承诺，应以实际质量和授权为准 | [00-META-00](../skills/00-META-00_好东西都是总结出来的.md)（第 94–106、526–543、824–844 行） |
| `01` 反思 | 是 | 侦察→执行→验证，错误模式逐轮积累并判断收敛 | 适用于 AI 生成内容或复杂规则结果；必须保留人工复核和停止条件，不把 Agent 自评当验收 | [00-META-01](../skills/00-META-01_反思.md)（第 97–128、222–236、391–430 行） |
| `02` 迭代工作流 | 是 | 先覆盖、再发现模式、再收敛和终态验证 | 可用于软件、数据和研究交付；“60%”“30%”“98%”等数值只能作为项目配置，不是通用门槛 | [00-META-02](../skills/00-META-02_迭代工作流.md)（第 15–17、53–77、185–209、238–262 行） |
| `03` 冷启动 | 是 | 任务定义→多样样本→最小规则→小试点→规则升级 | 新项目或新工序启用；样本数量、成功率和时间预算由目标项目设定 | [00-META-03](../skills/00-META-03_冷启动.md)（第 75–117、167–186、936–947 行） |
| `04` 柳叶刀方法 | 是 | 复杂任务拆成可独立验证的子任务，并按规则/代码/LLM选择方案 | 作为架构和任务分解原则；“能用规则不用 LLM”应改成“确定性部分优先规则，语义不确定部分才用模型” | [00-META-04](../skills/00-META-04_柳叶刀方法.md)（第 11–20、156–184、330–365 行） |
| `05` 上下文压缩 | 条件通用 | 将高频、稳定知识结构化以减少重复上下文和查询成本 | 只有当知识会被重复查询、关系需要显式推理且收益覆盖建模成本时启用；不强制所有项目建设知识图谱 | [00-META-05](../skills/00-META-05_知识作为上下文压缩.md)（第 11–15、86–106、1185–1203 行） |
| `06` Skill 演化 | 是 | 从日志和错误模式形成 Skill，渐进载入、版本化、定期精简 | 作为 Codex Skill 生命周期；拆分过长文档，保留触发、输入、输出、失败边界和验证，不追求文档数量 | [00-META-06](../skills/00-META-06_SKILL优化与演化.md)（第 10–20、116–123、418–437、748–752 行） |
| `07` 可读性 | 是 | 人类优先、Git 友好、中间结果可见、摘要到原始的渐进视图 | Markdown/JSON 是可选实现，不是硬性格式；关键要求是可阅读、可比较、可恢复 | [00-META-07](../skills/00-META-07_可读性.md)（第 11–22、125–130、468–470 行） |
| `08` 标注体系 | 条件通用 | 先定义类型、边界、消歧和版本迁移，再建立工具链 | 仅在文本标注、语义增强或 Schema 演化项目启用；18 类实体和 `〖〗` 符号不可迁移 | [00-META-08](../skills/00-META-08_标注体系设计.md)（第 38–43、86–115、191–210、481–503 行） |
| `09` Agent 提示词工程 | 是 | 目标→约束→方法→验证→输出五层结构 | 将 Claude 专用措辞替换为 Codex；把副作用、工具调用、输出 Schema 和终止条件写成显式契约 | [00-META-09](../skills/00-META-09_Agent提示词工程.md)（第 15–17、34–36、57–62、85–90、161–200、807–815 行） |
| `10` 质量控制 | 是 | 确定性检查先行、分级输出、快速失败、正确退出码 | 与反思分离：规则能确定判断时用脚本，主观语义留给人工/Agent；ERROR 阻断，WARNING/INFO 分级处理 | [00-META-10](../skills/00-META-10_质量控制.md)（第 25–33、133–137、576–607 行） |
| `11` 数据体感 | 是（数据/AI 项目） | 统计、抽样、异常检测、可视化和人工观察结合；中间结果文件化 | 不适用于纯文档小改动的强制流程；对批处理、数据分析和模型输出应保留抽样与可见中间产物 | [00-META-11](../skills/00-META-11_数据体感培养.md)（第 17–22、55–57、93–95、593–602、1120–1141 行） |
| `12` 数据融合 | 条件通用 | 分层对齐、实体/时间消歧、冲突记录、跨源验证和人工覆盖 | 仅在多来源数据存在冲突时启用；必须保留来源、置信度和冲突，不得静默覆盖原始观点 | [00-META-12](../skills/00-META-12_数据融合.md)（第 1480–1487、1806–1814 行） |
| `13` 技能迁移 | 是 | 直接复用、适配调整、重新设计三级迁移，并以试点驱动 | 迁移前先盘点依赖、路径、平台和副作用；任何领域规则、固定命令和绝对路径都不得直接复制 | [00-META-13](../skills/00-META-13_技能迁移.md)（第 33–42、56–64、123–129、172–176、201–203、548–556 行） |

### 15.2 对 00-META 体系本身的优化

原体系经验丰富，但文件较长、交叉引用较多，直接全部加载会增加 Agent 上下文成本。建议做以下优化：

1. **建立“核心总则 + 按需 Skill + 证据参考”三级载入**：`00`、`09`、`10` 保留为核心入口；`01`、`02`、`03`、`04`、`06`、`13` 按任务触发；史记案例、数学推导和长代码移入 `references/`。这直接落实 `00-META-06` 的渐进载入原则。
2. **去除重复规则，保留唯一权威来源**：冷启动、迭代、反思和质量控制中重复出现的“试点、验证、收敛”只保留一份规范，其他文档通过链接引用，避免规则漂移。
3. **把固定数字改为配置项**：例如样本数、准确率、修正量下降比例、压缩比和查询次数统一放入项目配置，并记录“指标定义、计算脚本、适用范围和调整理由”。
4. **把经验改写成可执行契约**：每个 META/Skill 增加 `触发条件、前置输入、步骤、输出、失败边界、验证命令、人工确认点` 七个字段；没有这些字段的内容只能作为参考，不能作为自动执行规则。
5. **明确规则、模型和人工的分工**：确定性格式和一致性问题交给脚本；开放语义判断交给 Agent；发布、规则升级、冲突裁决和外部写入保留人工批准。
6. **增加版本和淘汰机制**：每次规则变化记录来源日志、影响范围和验证结果；连续多个周期未触发或与其他 Skill 重复的规则进入待审计列表，而不是无限追加。
7. **统一跨平台实现**：将 Bash、`date -d`、Linux 绝对路径和 Claude 命令转换为 Python/PowerShell、仓库相对路径和 Codex Skill；脚本必须支持 dry-run、结构化输出、退出码和幂等运行。

### 15.3 推荐的通用 META 调用顺序（绑定文件）

| 顺序 | META 经验 | Codex 调用文件 | 何时调用 | 必须留下的产物 |
|---|---|---|---|---|
| 1 | `00` 总则/Bootstrap | `skills/methods/00-META-00_好东西都是总结出来的.md` + `AGENTS.md` | 每次任务开始与结束 | 范围摘要、最小交付、可沉淀经验 |
| 2 | `03` 冷启动或 `13` 迁移 | `skills/methods/00-META-03_冷启动.md`；迁移时加 `.codex/skills/transfer-pilot/SKILL.md`、`00-META-13_技能迁移.md` | 新工序或复用外部规则 | 试点方案、依赖盘点、迁移/回滚决策 |
| 3 | `04` 柳叶刀分解 | `skills/methods/00-META-04_柳叶刀方法.md`（按需迁移） | 所有中等及以上复杂任务 | 子任务清单、规则/脚本/模型选择 |
| 4 | `09` 提示词工程 | `skills/methods/00-META-09_Agent提示词工程.md` | 需要 Agent 执行或协作时 | 目标、约束、验证、输出 Schema、终止条件 |
| 5 | `07` 可读性 | `skills/methods/00-META-07_可读性.md`（按需迁移） | 所有会产生文档、数据或中间结果的任务 | 可读、可比较、可恢复的中间产物 |
| 6 | `11` 数据体感 | `skills/methods/00-META-11_数据体感培养.md`（按需迁移） | 批处理、数据分析、模型输出 | 抽样、统计、异常清单、可视化或人工观察记录 |
| 7 | `05/08/12` 条件方法 | `00-META-05` 已预置；`00-META-08`、`00-META-12` 按需迁移 | 分别在上下文复用、标注 Schema、多源冲突存在时 | 压缩依据、标注版本、来源/置信度/冲突记录 |
| 8 | `10` 质量控制 | `.codex/skills/quality-gate/SKILL.md` + `skills/methods/00-META-10_质量控制.md` | 基线、实现后、迁移和发布前 | 分层检查结果、命令、退出码和未执行项 |
| 9 | `02` 迭代工作流 | `skills/methods/00-META-02_迭代工作流.md` | 首轮验证未覆盖或需收敛时 | 覆盖率/错误模式/收敛判断/终态验证 |
| 10 | `01` 反思 | `.codex/skills/reflection-loop/SKILL.md` + `skills/methods/00-META-01_反思.md` | 失败、重复错误或偏差出现时 | 事实与推测区分、根因和最小改进建议 |
| 11 | `06` Skill 演化 | `.codex/skills/skill-authoring/SKILL.md` + `skills/methods/00-META-06_SKILL优化与演化.md` | 反思建议经人工批准后 | 新/改 Skill、版本、试点证据和淘汰记录 |

固定主链为：

```text
00 → 03/13 → 04 → 09 → 07 →（数据任务：11；条件任务：05/08/12）→ 10 → 02 →（必要时 01）→（批准后 06）→ 00 Bootstrap 回写
```

`05`、`08`、`12` 是条件分支，不应为普通任务强行启用；`01` 和 `06` 是反馈分支，不应在没有失败证据或人工批准时自动触发。每个 META 文件只负责方法规则，具体项目的路径、阈值、命令和权限必须写在项目 `AGENTS.md`、对应治理 Skill 或项目配置中。
