# Codex 工作路由

本文件只负责决定“什么时候调用什么文件”。每次工作时先读本文件，再按条件读取下列文件。路径均相对于本文件所在的 `codex-project-kit/` 目录。

## 1. 每次任务先调用

按顺序读取：

1. `AGENTS.template.md`：项目边界、目录责任、权限和命令基线。
2. `README.md`、依赖文件和 `log/`：确认项目事实和已有改动。
3. `.codex/skills/project-governance/SKILL.md`：建立本次任务范围。
4. `skills/methods/00-META-00_好东西都是总结出来的.md`：确定最小交付和可沉淀经验。
5. `skills/governance/SKILL_10_项目管理.md`、`skills/governance/SKILL_10a_TODO和Issue管理.md`：建立或更新 TODO/Issue。

如果项目根目录、目标文件、适用规则或验收标准不明确，停止并记录问题，不猜路径、不扩大范围。

## 2. 默认主流程

按以下顺序执行；不满足条件的步骤跳过：

```text
任务进入 → 建账 → 冷启动/迁移 → 分解 → 基线 → 实现
→ 条件处理 → 质量门 → 迭代（必要时）→ 记账
→ 反思（必要时）→ Skill 演化（批准后）→ 交付 → 经验回写
```

### 2.1 任务进入与建账

- 调用：`.codex/skills/project-governance/SKILL.md`、`skills/governance/SKILL_10_项目管理.md`、`skills/governance/SKILL_10a_TODO和Issue管理.md`。
- 适用：每个新请求、范围变化或继续未完成任务。
- 必须写明：目标、非目标、目标文件、Must/Should、验收标准、验证命令、依赖和风险。
- 通过条件：每个 TODO/Issue 都能独立验证；否则留在建账阶段。

### 2.2 冷启动或规则迁移

- 新工序/新项目：调用 `skills/methods/00-META-03_冷启动.md`。
- 复用其他项目规则：先调用 `.codex/skills/transfer-pilot/SKILL.md`，再调用 `skills/methods/00-META-13_技能迁移.md`。
- 必须产出：依赖、平台、路径、权限和副作用检查，以及迁移/回滚决定。
- 按需文件尚未安装时，只能放入 `references/source-derived/` 试点，不能直接引用源项目绝对路径。

### 2.3 任务分解与 Agent 调度

- 复杂任务、流水线或需要在规则与模型/人工之间分工时：先调用 `skills/methods/00-META-04_精细分解与混合方案.md`。
- 中等及以上复杂任务：按 `skills/methods/00-META-09_Agent提示词工程.md` 拆分执行边界。
- 设计字段、标注类型、Schema、消歧或格式迁移：调用 `skills/methods/00-META-08_标注与Schema设计.md`。
- 需要 Codex 执行、协作或生成提示词：调用 `skills/methods/00-META-09_Agent提示词工程.md`。
- 分解结果必须包含：子任务责任、输入、输出、失败边界和验证方式。

### 2.4 基线与最小实现

- 修改前：调用 `.codex/skills/quality-gate/SKILL.md`、`skills/methods/00-META-10_质量控制.md`、`skills/governance/SKILL_10c_Git代码版本管理规范.md`；运行最小现有检查并查看 `git status`/`git diff`。
- 只修改建账时声明的文件；批量写入先 dry-run；新增依赖、服务、数据库或公共接口时暂停确认。

### 2.5 条件知识复用

- 高频重复查询、稳定知识需要复用：调用 `skills/methods/00-META-05_知识作为上下文压缩.md`。
- 需要设计人读/机读兼容的表格、日志、报告或数据文件：调用 `skills/methods/00-META-07_可读性与数据表示.md`。
- 需要批量处理数据、模型输出或生成产物：调用 `skills/methods/00-META-11_数据可观测性与直接审查.md`，至少保留统计、规则和代表性样本证据。
- 需要合并多个来源、版本或异构格式：调用 `skills/methods/00-META-12_多源数据融合.md`，先登记来源和冲突策略，再生成可追溯的统一结果。
- 条件不满足时跳过，不为普通任务强行建立知识资产。

### 2.6 质量门与迭代

- 实现后和交付前都调用 `.codex/skills/quality-gate/SKILL.md` + `skills/methods/00-META-10_质量控制.md`。
- 按 L1（静态）→ L2（单元/契约）→ L3（集成）→ L4（真实用户路径）→适用的 L5（发布）执行。
- ERROR 阻断；WARNING 必须有处置决定；未执行项标记为“未执行”。
- 首轮验证未覆盖或错误模式未收敛：调用 `skills/methods/00-META-02_迭代工作流.md`，完成后回到质量门。

### 2.7 记账、反思与规则演化

- 每次任务结束：调用 `skills/governance/SKILL_10b_每日工作日志维护.md`、`skills/governance/SKILL_10d_CHANGELOG编写规范.md`、`skills/governance/SKILL_10g_项目成本与时间统计.md`，按 `skills/templates/daily-log.md` 记录到 `log/`，并更新 `CHANGELOG.md`。
- 失败、重复错误或偏差：调用 `.codex/skills/reflection-loop/SKILL.md` + `skills/methods/00-META-01_反思.md`，使用 `skills/templates/reflection-report.md`。
- 反思建议经人工批准后才可改进 Skill：调用 `.codex/skills/skill-authoring/SKILL.md` + `skills/methods/00-META-06_SKILL优化与演化.md`，先小范围试点并保留版本和证据。
- 没有失败证据或人工批准时，不调用反思升级或 Skill 演化流程。

### 2.8 交付与经验回写

- 交付前：再次调用 `.codex/skills/quality-gate/SKILL.md`，确认改动、验证结果、未执行项、残余风险和下一步。
- 用户可见行为改变：同步 `README.md` 和 `CHANGELOG.md`；其他说明文档仅在项目已有对应文件时更新。
- `git commit`、`git push`、发布、删除、覆盖、凭据访问和外部写入：只能先预览，获得明确确认后再调用 `skills/governance/SKILL_10c_Git代码版本管理规范.md` 执行，并再次验证。
- 任务结束：回到 `skills/methods/00-META-00_好东西都是总结出来的.md`，只回写已被日志或验证证据支持的可复用经验。

## 3. 停止条件

出现任一情况，停止当前步骤并记录，不继续调用后续实现流程：

- 需求、架构、权限或验收标准冲突；
- 目标路径或文件责任不清；
- 可能覆盖用户已有改动；
- 质量门出现 ERROR，或 WARNING 没有处置决定；
- 需要未批准的新依赖、服务、数据源、凭据或范围；
- 迁移缺少试点、owner 或回滚方案；
- 需要执行尚未授权的外部写入或发布动作。

## 4. 最短调用顺序

```text
AGENTS.template.md + README.md
→ .codex/skills/project-governance/SKILL.md
→ skills/governance/SKILL_10_项目管理.md + skills/governance/SKILL_10a_TODO和Issue管理.md
→ skills/methods/00-META-03_冷启动.md（新工序）或 .codex/skills/transfer-pilot/SKILL.md + skills/methods/00-META-13_技能迁移.md（迁移）
→ skills/methods/00-META-09_Agent提示词工程.md（复杂任务或需要 Agent 时）
→ skills/methods/00-META-04_精细分解与混合方案.md（复杂分解或混合执行时）
→ skills/methods/00-META-08_标注与Schema设计.md（设计标注、Schema或格式迁移时）
→ .codex/skills/quality-gate/SKILL.md + skills/methods/00-META-10_质量控制.md（基线）
→ skills/methods/00-META-05_知识作为上下文压缩.md（需要知识复用时）
→ skills/methods/00-META-07_可读性与数据表示.md（输出需兼顾人读/机读时）
→ skills/methods/00-META-11_数据可观测性与直接审查.md（批处理或数据产物时）
→ skills/methods/00-META-12_多源数据融合.md（多源或多版本合并时）
→ .codex/skills/quality-gate/SKILL.md（实现后）
→ skills/methods/00-META-02_迭代工作流.md（需要迭代时）
→ skills/governance/SKILL_10b_每日工作日志维护.md + skills/governance/SKILL_10d_CHANGELOG编写规范.md + skills/governance/SKILL_10g_项目成本与时间统计.md（记账）
→ .codex/skills/reflection-loop/SKILL.md + skills/methods/00-META-01_反思.md（失败时）
→ .codex/skills/skill-authoring/SKILL.md + skills/methods/00-META-06_SKILL优化与演化.md（人工批准后）
→ .codex/skills/quality-gate/SKILL.md + 授权后的交付动作
→ skills/methods/00-META-00_好东西都是总结出来的.md（经验回写）
```

文件不适用或条件不满足时，记录“跳过/未执行”及原因，不伪造调用结果。
